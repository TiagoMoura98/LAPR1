public class MathUtils {

    // Methods related to Euler and RK4
    // Methods for math application

    public static int methodEuler(int x0, int y0) { //Informação retirada do enunciado pagina 3
        int funcX=0; // valor de X em X0
        int funcY=0; // valor de Y em Y0
        int funcYn=0; // Valor e Y para N
        int number_of_Steps=0; // valor de N
        int steps = 0; // valor de H
        int contador = 0;

        do {
            funcYn= funcY+steps*(funcX+contador*steps & funcYn);
            funcY = funcYn;
            contador++;
        }while (contador<number_of_Steps);

        return funcYn;
    }

    public static int methodRK4(int x0, int y0) { //Informação retirada do enunciado pagina 4

        int funcX0 = 0; // valor de X em X0
        int funcY0 = 0; // valor de Y em Y0
        int funcYN; // Valor e Y para N
        int number_of_steps = 0; // valor de N
        int steps = 0; // valor de H
        int countador = 0; // valor de I toma a função de contador
        int k1=0; // RUNGE-KUTTA  de 1ºordem
        int k2=0; //RUNGE-KUTTA de 2ºordem
        int k3=0; //RUNGE-KUTTA de 3ºordem
        int k4=0; //RUNGE-KUTTA de 4ºordem
        int sumOfK=0;

        do {
            k1=number_of_steps*(funcX0 &funcY0);
            k2=number_of_steps*(funcX0+steps/2 & funcY0+k1/2 );
            k3=number_of_steps*(funcX0+steps/2 & funcY0+k2/2);
            k4=steps*(funcX0+steps & funcY0+k3);
            sumOfK=(k1+2)*(k2+2)*(k3+k4)/6;

            funcYN = funcY0+sumOfK;
            countador++;
            funcX0=funcX0+steps;
            funcY0=funcYN;

        }while (countador<number_of_steps);

        return funcYN;
    }


}
