import java.io.*;
import java.util.ArrayList;

public class FileManager {

    //TODO pass file path in the method, for now we will declare it here
    private final static String fileReadPath = "/Users/tiagomoura/Downloads/exemplo_parametros_modelo.csv";
    public static ArrayList<Pessoa> getPessoasFromFile() throws IOException {

        //Stream from File
        FileInputStream file = new FileInputStream(fileReadPath);
        BufferedReader read = new BufferedReader(new InputStreamReader(file));

        ArrayList<Pessoa> pessoas = new ArrayList<>();

        //Check the line count to ignore the first line
        int lineCount = 0;
        do{
            //Read line by line
            String line = read.readLine();

            //If first line we ignore it
            if (lineCount > 0) {

                //check if line is empty
                if (!line.equals("")) {

                    String[] fields = line.split(";");

                    //Check if all rows are filled
                    if (fields.length == 5) {
                        System.out.println("Processing line: " + line);

                        //Catch possible parsing errors
                        try {

                            pessoas.add(new Pessoa(
                                    //name
                                    fields[0],
                                    //beta
                                    Float.parseFloat(fields[1].replace(",", ".")),
                                    //gamma
                                    Float.parseFloat(fields[2].replace(",", ".")),
                                    //ro
                                    Float.parseFloat(fields[3].replace(",", ".")),
                                    //alpha
                                    Float.parseFloat(fields[4].replace(",", "."))
                            ));

                        }catch (Exception e){
                            System.out.println("Line value parsing exception: " + e);
                        }

                    }
                }

            }
            /*
            else{
                //line contains the table headers
                //if we need to do something with the header values we can do it here
            }
            */
            lineCount++;

        }
        while (read.ready());

        //Output testing
        System.out.println("==========DEBUG FILE READ==============");
        System.out.println("Persons loaded from file: "+pessoas.size());
        for (Pessoa pessoa : pessoas){
            System.out.println(pessoa.getName()+": "+pessoa.getBeta()+" | "+pessoa.getGama()+" | "+pessoa.getRo()
                    +" | "+pessoa.getAlfa());
        }
        System.out.println("===========END DEBUG==============");

        return pessoas;
    }


}
