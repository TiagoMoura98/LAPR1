public class GraphManager {

    // Methods related to the graph output of the results


}
