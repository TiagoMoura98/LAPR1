
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class project_09 {

    private static MenuUtils menu; //initializing menu class
    static Scanner read = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        char[][] contentRecived;

        menuOptions(); // recebe informação de todos os outros metodos;
        ArrayList<Pessoa> pessoas = FileManager.getPessoasFromFile();

        contentRecived=readFiles();

        rollBackMenu();

        printFiles(contentRecived);

        interactiveFunction();

        nonInteractiveFuncion();

        int b = 0; // valor temp, depois ter]a de ser passar os parametros de entrada para o metodo funcionar
        int a = 0; // valor temp, depois ter]a de ser passar os parametros de entrada para o metodo funcionar
        MathUtils.methodEuler(a,b); // a rever pois apenas retira informção do pseudocodigo do enunciado
        
        MathUtils.methodRK4(a,b);// a rever pois apenas retira informção do pseudocodigo do enunciado

        compareMathModules();

        graphicModule();

        saveGraphicalOutput();

        fileOutput();

        graphicalOutput();

        // int additionalVariables = askFurtherInformation();


    }

    /*private static int askFurtherInformation() {

        System.out.println("Define Number of Steps");

        int numberOfSteps= read.nextInt();

        while (numberOfSteps<0 || numberOfSteps) {

            System.out.println("Number Inserted not Recognized, Please Define Again Number of Steps");

            int numberOfSteps= read.nextInt();
           }           

        return 0;
    } */

    public static void checkFiles(File check) {

        if (check.length()==0 || !check.exists()){
            System.out.println("No information on file or does not exist");  // necessita de ir para dentro do readFile
            System.exit(0);
        }
    }
    private static char[][] readFiles() throws FileNotFoundException {
        char [][] content;
        char row;
        char colluns;

        File file = new File("exemplo_parametros_modelo.txt");
        checkFiles(file);

        read = new Scanner(file);
        read.nextLine();

        String contentSize = read.nextLine();
        String[] size = contentSize.split(" ");

        row = (char) Integer.parseInt(size[0]);
        colluns = (char) Integer.parseInt(size[1]);

        content= new char[row][colluns];
        for (int i = 0; i < row; i++) {

            String strRow = read.nextLine();
            String[] vectorRow = strRow.split(" ");

            for (int j = 0; j < colluns; j++) {
                content[i][j]= (char) Integer.parseInt(vectorRow[j]);
            }

        }
        read.close();

        return content;


    }
    private static int menuOptions () {

        int optionSelection = 0;
        int ciclos =0;

        do{

            if (ciclos>0){
                System.out.println("You have inputed a wrong choice of menu\n");
            }
            System.out.println("Welcome");
            System.out.println("Choose one of the following choises");
            System.out.println("-----------------------------------");
            System.out.println("1----------Display Interactive Mode");
            System.out.println("2--------------Non-Interactive Mode");
            System.out.println("3------------------Display-Graphics");
            System.out.println("4------------------------------Exit");

            optionSelection= read.nextInt();
            switch (optionSelection) {
                case 1:
                    System.out.println("Welcome to Interactive Mode");
                    break;
                case 2:
                    System.out.println("Display Content");
                    break;
                case 3:
                    System.out.println("Here you graph");
                    break;
                case 4:
                    System.exit(0);
                    break;
            }
            ciclos++;

        }while(optionSelection == 0 || optionSelection>4);

        return optionSelection;

    }

    // Creio que este metodo já não seja necessário depois do que alterei no metodo menuOptions
   private static void rollBackMenu() {
        System.out.println("Go back to the previous menu"); // se for colocado um input incorrecto roll back automaticamente para o menu anterior
    }

    private static void interactiveFunction() {
    }


    private static void nonInteractiveFuncion() {
    }

    private static void printFiles(char[][] content) {
        for (int i = 0; i < content.length; i++) {
            for (int j = 0; j < content[i].length; j++) {
                if (j != content[i].length){
                    System.out.println(content[i][j]);
                }
            }

        }

    }

    private static void compareMathModules() {
    }

    private static void graphicModule() {
    }

    private static void fileOutput() {
    }


    private static void graphicalOutput() {
    }

    private static void saveGraphicalOutput() {
    }










}
