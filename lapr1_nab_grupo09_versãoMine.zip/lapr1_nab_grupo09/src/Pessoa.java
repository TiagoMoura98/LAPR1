public class Pessoa {
    private final String name;
    private final float beta;
    private final float gama;
    private final float ro;
    private final float alfa;

    public Pessoa(String nome, float beta, float gama, float ro, float alfa) {
        this.name = nome;
        this.beta = beta;
        this.gama = gama;
        this.ro = ro;
        this.alfa = alfa;
    }

    public String getName() {
        return name;
    }

    public float getBeta() {
        return beta;
    }

    public float getGama() {
        return gama;
    }

    public float getRo() {
        return ro;
    }

    public float getAlfa() {
        return alfa;
    }

}