import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MenuUtils {

    // All methods related to the production of menus

}
